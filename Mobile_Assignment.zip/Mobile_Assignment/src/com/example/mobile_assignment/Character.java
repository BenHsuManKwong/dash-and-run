package com.example.mobile_assignment;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;

public class Character {
	private int x;
	private double y;
	private int width;
	private double height;
	private int screenH;
	private int screenW;
	public double gravity = 15.5;
	public int terminal_v = 300;
	public double upSpeed = 31;
	public double temp = 0.5;
	public boolean jump = false;
	Paint p = new Paint();
	public Bitmap b[];
	int currentFrame = 0;
	
	
	
	public Character(Bitmap b[],int x,int y,int screenH,int screenW){
		this.b = b;
		this.x = x;
		this.y = y;
		this.screenH = screenH;
		this.screenW = screenW;
		
		width = x+b[0].getWidth();
		height = y+b[0].getHeight();
		
		
		
		
	}
	public void drawBit(Canvas canvas) {

		canvas.drawBitmap(b[currentFrame], x, (float) y, null);
		if(jump==true){
			currentFrame=8;
		}
		else{
			if(currentFrame<8)
				currentFrame++;
			if(currentFrame>=8){
				currentFrame=0;
			}
		}
	}

	public String getstate(){
		String s = "x="+x+" ,y="+y+" ,widrh="+width+" ,height="+height;
		
		
		return s;
	}
	public void drap(double ground){
		height = y+b[0].getHeight();
		if(height>=ground){
			y=ground-b[0].getHeight();
			
		}
		else if(height<ground){
			y = y+gravity;
			
		}
	}


	public void jump(){

		y = y-(int)(upSpeed);
		height = height-(int)(upSpeed);
	}
	public double getY(){
		return y;
	}
	
	public double getX(){
		return x;
	}
	
	public double getH(){
		return height;
	}
	
	public double JumpMax(){
		return screenW/2;
	}

	public double getW(){
		return b[0].getWidth();
	}
	
	public void setJump(boolean jump){
		this.jump = jump;
		
	}
	
	
	
	
}
