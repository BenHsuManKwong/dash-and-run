/**
 * 
 */
package com.example.mobile_assignment;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.util.Log;
import android.view.MotionEvent;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import android.media.MediaPlayer;

public class MainGame extends SurfaceView implements
		SurfaceHolder.Callback {

	private static final String TAG = MainGame.class.getSimpleName();
	
	private MainThread thread;
	private Block_01 b01[] = new Block_01[2];
	private Block_02 b02[] = new Block_02[1];
	private Block_03 b03[] = new Block_03[2];
	private Ground ground;
	private Background_upper bgu,bgu2,bgu3;
	private Character c;
	boolean gameOver = false;
	
	int damage = 0;
	int score = 0;
	Paint tPaint = null;
	int screenH;
	int screenW;
	boolean touch = false;
	boolean canTouch = true;
	boolean onJump = false;
	boolean cap = false;
	int counter = 0;
	double temp = 0;
	Bitmap b_01,b_02,b_03;
	Bitmap c_frame[] = new Bitmap[9];
	Bitmap bg_under;
	Bitmap bg_upper;
	private MediaPlayer bgm;
	private MediaPlayer jump;
	private MediaPlayer hit;
	boolean bgmOn;
	boolean seOn;
	
	
	
	
	
	public MainGame(Context context) {
		super(context);
		getHolder().addCallback(this);
		thread = new MainThread(getHolder(), this);
		setFocusable(true);
		
		

		
	}

	


	
	
	

	public void surfaceChanged(SurfaceHolder holder, int format, int width,
			int height) {
		
		if(((Activity)getContext()).getIntent().getExtras().getString("bgmOn").equals("0"))
        	bgmOn = true;
        else
        	bgmOn = false;
		
		if(((Activity)getContext()).getIntent().getExtras().getString("seOn").equals("0"))
        	seOn = true;
        else
        	seOn = false;
		
		Log.i("***", "bgm=" + bgmOn );
		Log.i("***", "se=" + seOn);
		
		
		bgm = MediaPlayer.create(getContext(), R.raw.bgm);
		bgm.setLooping(true);
		jump= MediaPlayer.create(getContext(), R.raw.jump);
		hit = MediaPlayer.create(getContext(), R.raw.hit);
		int screenH = getHeight();
		int screenW = getWidth();
		int posY;
		//int posX;
		int delat = 10;
		b_01 = Bitmap.createScaledBitmap(BitmapFactory.decodeResource(getResources(), 
				R.drawable.block_01),screenW/8,screenW/8,false);
		b_02 = Bitmap.createScaledBitmap(BitmapFactory.decodeResource(getResources(), 
				R.drawable.block_02),screenW/5,screenW/18,false);	
		b_03 = Bitmap.createScaledBitmap(BitmapFactory.decodeResource(getResources(), 
				R.drawable.block_03),screenW/5,screenW/20,false);
		setFrame(screenW);
		
		
		for(int i=0;i<2;i++){
			posY = (int)(Math.random()*(screenH*3/5-screenH/4+1))+(int)screenH/4;


			b01[i]=new Block_01(b_01,screenW+delat,posY,screenH,screenW);
			
			delat = delat + (int)(Math.random()*500)+250;

			b03[i]=new Block_03(b_03,screenW+delat,screenH*3/4-b_03.getHeight(),screenH,screenW);

			delat = delat + (int)(Math.random()*500)+250;
		}
		posY = (int)(Math.random()*(screenH*3/5-screenH/4+1))+(int)screenH/4;

		b02[0]=new Block_02(b_02,screenW+delat,posY,screenH,screenW);
		
		bg_under = Bitmap.createScaledBitmap(BitmapFactory.decodeResource(getResources(), 
				R.drawable.background_under),screenW,screenH/4,false);
		
		bg_upper = Bitmap.createScaledBitmap(BitmapFactory.decodeResource(getResources(), 
				R.drawable.background_upper),screenW*3/4,screenW/2,false);
		bgu= new Background_upper(bg_upper,screenW,screenH*3/4-bg_upper.getHeight(),screenH,screenW);
		
		bg_upper = Bitmap.createScaledBitmap(BitmapFactory.decodeResource(getResources(), 
				R.drawable.background_upper),screenW*3/4,screenW/4,false);
		bgu2= new Background_upper(bg_upper,screenW+delat,screenH*3/4-bg_upper.getHeight(),screenH,screenW);
		
		bg_upper = Bitmap.createScaledBitmap(BitmapFactory.decodeResource(getResources(), 
				R.drawable.background_upper),screenW/2,screenW/2,false);
		bgu3= new Background_upper(bg_upper,screenW+delat-30,screenH*3/4-bg_upper.getHeight(),screenH,screenW);		
		
		
		
		ground = new Ground(0,(int)screenH*3/4,(int)screenW,(int)screenH*3/4+2);
		c= new Character(c_frame,10,screenH/2-50,screenH,screenW);
		
		
	}


	public void surfaceCreated(SurfaceHolder holder) {
		
		thread.setRunning(true);
		thread.start();
	}


	public void surfaceDestroyed(SurfaceHolder holder) {
		Log.d(TAG, "Surface is being destroyed");

		boolean retry = true;
		while (retry) {
			try {
				
				thread.setRunning(false);
				Context c = getContext();
				Intent intent = new Intent(c,MainActivity.class);
				Intent i = new Intent();
				i.setClass(c, MainActivity.class);
				bgm.stop();
				thread.interrupt();
				c.startActivity(intent);
				thread.join();
				retry = false;
			} catch (InterruptedException e) {

			}
		}
		Log.d(TAG, "Thread was shut down cleanly");
	}

	public void render(Canvas canvas) {
		
		int screenH = getHeight();
		int screenW = getWidth();
		
		canvas.drawColor(Color.LTGRAY);

		Paint paint = new Paint();
		paint.setColor(Color.BLACK);
		canvas.drawBitmap(bg_under,0,screenH*3/4,null);
		

		
		bgu.drawBit(canvas);
		bgu2.drawBit(canvas);
		bgu3.drawBit(canvas);

		b01[0].drawBit(canvas);
		b01[1].drawBit(canvas);
		
		b02[0].drawBit(canvas);

		b03[0].drawBit(canvas);
		b03[1].drawBit(canvas);

		ground.draw(canvas);
		c.drawBit(canvas);
		paint.setTextSize(screenW/15);
		canvas.drawText("Score : "+score, screenW/20, screenH/20, paint);
		canvas.drawText("Damage : " + damage+" / 500",screenW/20, screenH/10, paint);
		if(gameOver){
			canvas.drawText("Game Over", screenW/4,screenH/2, paint);
			canvas.drawText("Your Score : " + score,screenW/4, screenH*2/3, paint);
		}
		
		
		
	}
	
	public void update(){
		if(bgmOn==true){
			bgm.start();
		}
		if(damage<500){
			b01[0].move();		
			b01[1].move();
			b02[0].move();
			b03[0].move();
			b03[1].move();
			bgu.move();
			bgu2.move();
			bgu3.move();
			c.drap(ground.getY());

			if(touch == true&&counter%2==1){
				c.jump();
				onJump = true;
				c.setJump(true);
				
				if(ground.getY()-c.getH()>=c.JumpMax()){
					touch = false;
					c.setJump(false);
				}

			}
		
			else if(counter%2==0 &&onJump==true&&counter !=0){
				if(cap == false){
					temp = c.getH();
					cap = true;
				}
				c.jump();
				touch =false;
				canTouch = false;
				c.setJump(true);
				
				if(temp-c.getH()>=c.JumpMax()){
					counter=0;
					c.setJump(false);
				}
				
			}
		
		
			if(c.getH()>=ground.getY()){
				canTouch=true;
				onJump=false;
				counter =0;
				cap = false;
				c.setJump(false);
			}
		
		
		
		
			for(int i=0;i<2;i++){
				if(c.getX()+c.getW()>=b01[i].getX()&&
						c.getX()+c.getW()<=b01[i].getX()+b01[i].getW()&&
						c.getH()>=b01[i].getY()&&
						c.getH()<=b01[i].getY()+b01[i].getH()){
					damage++;
					if(seOn==true){
						hit.start();
					}
				}
				else if(c.getX()+c.getW()>=b01[i].getX()&&
						c.getX()+c.getW()<=b01[i].getX()+b01[i].getW()&&
						c.getY()>=b01[i].getY()&&
						c.getY()<=b01[i].getY()+b01[i].getH()){
					damage++;
					if(seOn==true){
						hit.start();
					}
				}
				else if (c.getX()>=b01[i].getX()&&
						c.getX()<=b01[i].getX()+b01[i].getW()&&
						c.getH()>=b01[i].getY()&&
						c.getH()<=b01[i].getY()+b01[i].getH()){
					damage++;
					if(seOn==true){
						hit.start();
					}
				}
				else if (c.getX()>=b01[i].getX()&&
						c.getX()<=b01[i].getX()+b01[i].getW()&&
						c.getY()>=b01[i].getY()&&
						c.getY()<=b01[i].getY()+b01[i].getH()){
					damage++;
					if(seOn==true){
						hit.start();
					}
				}
				
				
			}
			
			for(int i=0;i<2;i++){
				if(c.getX()+c.getW()>=b03[i].getX()&&
						c.getX()+c.getW()<=b03[i].getX()+b03[i].getW()&&
						c.getH()>=b03[i].getY()&&
						c.getH()<=b03[i].getY()+b03[i].getH()){
					damage++;
					if(seOn==true){
						hit.start();
					}
				}
				else if(c.getX()+c.getW()>=b03[i].getX()&&
						c.getX()+c.getW()<=b03[i].getX()+b03[i].getW()&&
						c.getY()>=b03[i].getY()&&
						c.getY()<=b03[i].getY()+b03[i].getH()){
					damage++;
					if(seOn==true){
						hit.start();
					}
				}
				else if (c.getX()>=b03[i].getX()&&
						c.getX()<=b03[i].getX()+b03[i].getW()&&
						c.getH()>=b03[i].getY()&&
						c.getH()<=b03[i].getY()+b03[i].getH()){
					damage++;
					if(seOn==true){
						hit.start();
					}
				}
				else if (c.getX()>=b03[i].getX()&&
						c.getX()<=b03[i].getX()+b03[i].getW()&&
						c.getY()>=b03[i].getY()&&
						c.getY()<=b03[i].getY()+b03[i].getH()){
					damage++;
					if(seOn==true){
						hit.start();
					}
				}
			
			}
			for(int i=0;i<1;i++){
				if(c.getX()+c.getW()>=b02[i].getX()&&
						c.getX()+c.getW()<=b02[i].getX()+b02[i].getW()&&
						c.getH()>=b02[i].getY()&&
						c.getH()<=b02[i].getY()+b02[i].getH()){
					damage++;
					if(seOn==true){
						hit.start();
					}
				}
				else if(c.getX()+c.getW()>=b02[i].getX()&&
						c.getX()+c.getW()<=b02[i].getX()+b02[i].getW()&&
						c.getY()>=b02[i].getY()&&
						c.getY()<=b02[i].getY()+b02[i].getH()){
					damage++;
					if(seOn==true){
						hit.start();
					}
				}
				else if (c.getX()>=b02[i].getX()&&
						c.getX()<=b02[i].getX()+b02[i].getW()&&
						c.getH()>=b02[i].getY()&&
						c.getH()<=b02[i].getY()+b02[i].getH()){
					damage++;
					if(seOn==true){
						hit.start();
					}
				}
				else if (c.getX()>=b02[i].getX()&&
						c.getX()<=b02[i].getX()+b02[i].getW()&&
						c.getY()>=b02[i].getY()&&
						c.getY()<=b02[i].getY()+b02[i].getH()){
					damage++;
					if(seOn==true){
						hit.start();
					}
				}

			
			}
			score++;
		}
		
		
		else if(damage>=500){
			gameOver = true;
		}
	}
	@Override
	public boolean onTouchEvent(MotionEvent event) {

		if(canTouch){
			if(seOn ==true){
				jump.start();
				
			}
			touch = true;
			counter++;
			return super.onTouchEvent(event);
		}
		else{
			return false;
		}
		
		
	}
	
	public void setFrame(double w){
		
		c_frame[0] = Bitmap.createScaledBitmap(BitmapFactory.decodeResource(getResources(),
				R.drawable.frame_01),(int) (w/8),(int)w/8,false);
		c_frame[1] = Bitmap.createScaledBitmap(BitmapFactory.decodeResource(getResources(),
				R.drawable.frame_02),(int) (w/8),(int)w/8,false);
		c_frame[2] = Bitmap.createScaledBitmap(BitmapFactory.decodeResource(getResources(),
				R.drawable.frame_03),(int) (w/8),(int)w/8,false);
		c_frame[3] = Bitmap.createScaledBitmap(BitmapFactory.decodeResource(getResources(),
				R.drawable.frame_04),(int) (w/8),(int)w/8,false);
		c_frame[4] = Bitmap.createScaledBitmap(BitmapFactory.decodeResource(getResources(),
				R.drawable.frame_05),(int) (w/8),(int)w/8,false);
		c_frame[5] = Bitmap.createScaledBitmap(BitmapFactory.decodeResource(getResources(),
				R.drawable.frame_06),(int) (w/8),(int)w/8,false);
		c_frame[6] = Bitmap.createScaledBitmap(BitmapFactory.decodeResource(getResources(),
				R.drawable.frame_07),(int) (w/8),(int)w/8,false);
		c_frame[7] = Bitmap.createScaledBitmap(BitmapFactory.decodeResource(getResources(),
				R.drawable.frame_08),(int) (w/8),(int)w/8,false);
		c_frame[8] = Bitmap.createScaledBitmap(BitmapFactory.decodeResource(getResources(),
				R.drawable.frame_09),(int) (w/8),(int)w/8,false);

	}


}
