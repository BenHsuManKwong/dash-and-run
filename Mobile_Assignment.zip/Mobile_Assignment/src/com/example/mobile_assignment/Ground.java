package com.example.mobile_assignment;


import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;

public class Ground extends Thread {
	

	
	int x = 0;
	int y = 0;
	int height=0;
	int width=0;
	int speed=10;
	int originX,originW,screenH,screenW;
	Paint p = new Paint();
	
	public Ground(int x,int y,int width,int height){
		this.x = x;
		this.y = y;
		this.height = height;
		this.width = width;
	}

	public void draw(Canvas canvas) {
		p.setColor(Color.BLACK);
		canvas.drawRect((float)x, (float)y, (float)width,(float)height,p);
		
	}
	public int getY(){
		return y;
	}

}
