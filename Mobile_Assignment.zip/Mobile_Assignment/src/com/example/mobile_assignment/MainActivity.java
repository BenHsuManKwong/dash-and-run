package com.example.mobile_assignment;



import android.media.MediaPlayer;
import android.os.Bundle;
import android.app.Activity;
import android.content.Intent;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.Display;
import android.view.Menu;
import android.view.MenuItem;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.view.View;
import android.widget.Toast;

public class MainActivity extends Activity implements View.OnClickListener {
    Button btnNew;
    Button btnCon;
    Button btnAbout;
    Button btnExit;
    boolean bgmOn = true;
    boolean seOn= true;
    
    
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        
        btnNew = (Button)findViewById(R.id.btn_new);    
        btnCon = (Button)findViewById(R.id.btn_continue);
        btnAbout = (Button)findViewById(R.id.btn_about);
        btnExit = (Button)findViewById(R.id.btn_exit);

        btnNew.setOnClickListener(this);   
        btnCon.setOnClickListener(this);
        btnAbout.setOnClickListener(this);
        btnExit.setOnClickListener(this);

        
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
    	menu.add(0,1,1,"BGM off");
    	menu.add(0,2,2,"BGM on");
    	menu.add(0,3,3,"SE off");
    	menu.add(0,4,4,"SE on");
    	
        getMenuInflater().inflate(R.menu.main, menu);
        
        return super.onCreateOptionsMenu(menu);
    }
    
    public void onClick(View v){
    	Toast toast;
    	switch(v.getId()){
    		case R.id.btn_continue:
    			toast = Toast.makeText(getApplicationContext(), "continue", Toast.LENGTH_SHORT);
    			toast.show();
    			break;
    		case R.id.btn_new:
    			
    			//setContentView(new MainGame(this));
    			Intent g =new Intent(this,GameActivity.class);
    			if(bgmOn == true){
    				g.putExtra("bgmOn", "0");
    			}
    			else{
    				g.putExtra("bgmOn", "1");
    			}

    			if(seOn == true){
    				g.putExtra("seOn", "0");
    			}
    			else{
    				g.putExtra("seOn", "1");
    			}
    			startActivity(g);
    			Log.i("***", "bgm=" + bgmOn );
    			Log.i("***", "se=" + seOn);
    	        

    			break;
    		case R.id.btn_about:
    			Intent i = new Intent(this, About.class);
    			startActivity(i);
    			break;
    		case R.id.btn_exit:
    			onDestroy();
    			break;
    		default:
    	
    	}
    	
    
    }
    public boolean onOptionsItemSelected(MenuItem item){
    	return (applyMenuOption(item) || 
    	super.onOptionsItemSelected(item));
    	}
    private boolean applyMenuOption(MenuItem item) {
    	int menuItemId = item.getItemId();
    	if(menuItemId == 1){
    		bgmOn = false;
			Toast toast = Toast.makeText(getApplicationContext(), "BGM off", Toast.LENGTH_SHORT);
			toast.show();
    	}
    	else if(menuItemId == 2){
    		bgmOn = true;
			Toast toast = Toast.makeText(getApplicationContext(), "BGM on", Toast.LENGTH_SHORT);
			toast.show();
    	}else if(menuItemId == 3){
    		seOn = false;
			Toast toast = Toast.makeText(getApplicationContext(), "SE off", Toast.LENGTH_SHORT);
			toast.show();
    	}else if(menuItemId == 4){
    		seOn = true;
			Toast toast = Toast.makeText(getApplicationContext(), "SE on", Toast.LENGTH_SHORT);
			toast.show();
    	}
    	return false;
    	}
    

    
    
    
    
    
    
    
    
}
