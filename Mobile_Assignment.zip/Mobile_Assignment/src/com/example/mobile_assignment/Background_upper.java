package com.example.mobile_assignment;



import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Paint;

public class Background_upper extends Thread {
	
	//DisplayMetrics dm = new DisplayMetrics();
	
	int x = 0;
	int y = 0;
	int height=0;
	int width=0;
	int speed=10;
	int originX,originW,screenH,screenW;
	Paint p = new Paint();
	Bitmap b;
	
	public Background_upper(Bitmap b,int x,int y,int screenH,int screenW){
		this.b = b;
		originX = x;
		originW = width;
		this.x = x;
		this.y = y;
		this.screenH = screenH;
		this.screenW = screenW;

	}

	
	
	public void drawBit(Canvas canvas) {

		canvas.drawBitmap(b, x, y, null);
	}

	
	public void move(){
		
		if(x+b.getWidth()>0){
			x = x-speed;
			width = width-speed;
		}
		else if(x+b.getWidth()<=0){
			x=screenW+(int)(Math.random()*(screenH-screenW)+1)+screenW/4;
			y = screenH*3/4-b.getHeight();
			}
		
		
		
	}
	public String getstate(){
		String s = "x="+x+" ,y="+y+" ,widrh="+width+" ,height="+height+" , b.W = "+b.getWidth();
		return s;
	}
	
	public int getY(){
		return y;
	}
	
	public int getX(){
		return x;
	}
	
	public double getH(){
		return b.getHeight();
	}
	public double getW(){
		return b.getWidth();
	}
	
}
