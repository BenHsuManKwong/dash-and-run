/** Automatically generated file. DO NOT MODIFY */
package com.example.mobile_assignment;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}